/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.marek.SpringBootDemo;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author Karol
 */
@RestController

@RequestMapping("/user")

public class UserController {

    @Autowired
    UserService service;
// era tipo void, pero le ponemos el repon para devolver el resultado 

    @PostMapping("/create")
    public ResponseEntity createUser(String nombre, String apellido, String fechaNacimiento) {

        service.userInofrmation(nombre, apellido, fechaNacimiento);

        return ResponseEntity.ok().build();

    }

    @GetMapping("/list")
    public ResponseEntity<String> listaUsuarios() {

        List<User> listaUsuario = service.getAllUsers();
        String resultado = "";
        for (User u : listaUsuario) {
            resultado += u.getNombre() + " \n";
        }
        return ResponseEntity.ok(resultado);

    }

    // en este caso, hay dos opciones, un request de vacio no content y en el otro el requiest y los valorss
    //las llaves para ver en php
    @GetMapping("/{id}")
    //depende de la version debemos de poner el values e igualrlo a la id values=("id")
    public ResponseEntity<String> getUserById(@PathVariable("id") Long id) {

        User usuario = service.getUserById(id);
        if (usuario == null) {
            //"El usuario con id=" + id + " no existe."
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.ok(usuario.getNombre());
        }

    }

    @GetMapping("/nombre/{name}")
    public List<User> getAllUsersByName(@PathVariable("name") String name) {

        List<User> listaUsuarios = service.getUserByName(name);
        return listaUsuarios;

    }

    @GetMapping("/sinFecha")
    public List<User> getAllUsersSinFecha() {
        List<User> listaUsuarios = service.getUsersSinFEcha();
        return listaUsuarios;

    }
}
