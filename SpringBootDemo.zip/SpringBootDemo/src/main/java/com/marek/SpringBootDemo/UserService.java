/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.marek.SpringBootDemo;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Karol
 */
@Service
public class UserService {

    //  @Autowired(required=false) // el false es para cuando no tenga mas metodos, depsues al definir mas metodos no hace falta 
    @Autowired
    UserRepository repository;

    public void userInofrmation(String nombre, String apellido, String fechaNacimiento) {
        User usuario = new User();
        usuario.setNombre(nombre);
        usuario.setApellido(apellido);
        usuario.setFechaNacimiento(fechaNacimiento);
        repository.save(usuario);
    }

    public List getAllUsers() {

        List<User> listaUsuarios = repository.findAll();

        return listaUsuarios;

    }

    public User getUserById(Long id) {
        Optional<User> usuario = repository.findById(id);
        if (usuario.isPresent()) {
            return usuario.get();
        } else {
            return null;
        }
    }

    public List<User> getUserByName(String nombre) {
        Optional<List<User>> listaUsuarios = repository.findAllUsersByNombre(nombre);
        if (listaUsuarios.isPresent()) {
            return listaUsuarios.get();
        } else {
            return null;
        }

    }

    public List<User> getUsersSinFEcha() {

        Optional<List<User>> listaUsuariosSnFecha = repository.listUsersSinsinFecha();
        if (listaUsuariosSnFecha.isPresent()) {
            return listaUsuariosSnFecha.get();
        } else {
            return null;
        }
    }

}
