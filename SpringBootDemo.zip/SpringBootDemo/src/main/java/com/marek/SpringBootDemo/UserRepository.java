/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.marek.SpringBootDemo;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Karol
 */
@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    @Override
    <S extends User> S save(S s);

    @Override
    List<User> findAll();

    @Override
//optional devuelve null si no existe nada y 
    //si existe da el user u otro objeto que estemos trabajando 

    Optional<User> findById(Long id);

    // tiene que coincidor el nombre final del metodo y el interior del metoso 
    Optional<List<User>> findAllUsersByNombre(String nombre);

    @Query(value = "select * from usuario where fechaN = \"\"", nativeQuery = true)
    Optional<List<User>> listUsersSinsinFecha();

}
