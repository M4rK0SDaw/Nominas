/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.marek.SpringBootDemo;

import com.itextpdf.text.DocumentException;
import java.io.IOException;
import org.apache.pdfbox.pdmodel.PDDocument;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author marek
 */
@RestController
@RequestMapping("/prueba")

public class Prueba_Controller {

    @Autowired
    Prueba_Service service;

    @GetMapping("/cratePDF")
    public void createPDF() throws IOException, DocumentException {
        // linea de vuelta del servicio
         service.prueba_crearPDF();

    }
}
