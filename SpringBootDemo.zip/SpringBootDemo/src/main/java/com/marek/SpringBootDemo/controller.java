/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.marek.SpringBootDemo;


import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author Karol
 */
@RestController
@RequestMapping("/url")
public class controller {

    @Autowired
    service service;

    @PostMapping("/mensaje")
    public String mensaje(@RequestParam(value = "mensaje") String mensaje) {
        return service.getMensaje(mensaje);
    }

    @PostMapping("/readfile")
    public String procesaFichero(HttpServletRequest request) {
        return service.getprocesaFichero(request);
    }

}
