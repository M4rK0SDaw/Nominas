/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.marek.SpringBootDemo;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import javax.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Service;

/**
 *
 * @author Karol
 */
@Service
public class service {
    //Aquí va toda la lógica

    public String getMensaje(String mensaje) {

        return mensaje;
    }

    public String getprocesaFichero(HttpServletRequest request) {
        String filecontent = "";
        try {
            InputStream input = request.getInputStream();
            byte[] data = new byte[1024];

            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            int lineRead;
            while ((lineRead = input.read(data, 0, data.length)) != -1) {
                buffer.write(data, 0, lineRead);
            }
            buffer.flush();
            filecontent = new String(buffer.toByteArray());
        } catch (IOException e) {
        }
        return filecontent;
    }
}
