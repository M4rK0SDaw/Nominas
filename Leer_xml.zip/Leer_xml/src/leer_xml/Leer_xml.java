/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package leer_xml;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;

/**
 *
 * @author Karol
 */
public class Leer_xml {

    private static final String FILENAME = "C:\\Users\\marqu\\OneDrive\\Documentos\\NetBeansProjects\\Mis_clases_Java\\Leer_XML\\Leer_xml\\src\\leer_xml\\convenio.xml";

    public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException {
        
        int empleado_grupo = 2;
        int empleado_nivel = 3;
        String empleado_letra = null;        
        // instancia la factoria
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

        // Parsear el fichero de XML
        DocumentBuilder db = dbf.newDocumentBuilder();
        Document doc = db.parse(new File(FILENAME));

        // Quitar infromacion redundante
        doc.getDocumentElement().normalize();
//                                          doc  busca root      devuelve nombre de la raiz o root
        System.out.println("Nodo raiz :" + doc.getDocumentElement().getNodeName());
        System.out.println("------");

        NodeList nodeListGrupoProfesional = doc.getElementsByTagName("grupo_profesional");

          System.out.println(nodeListGrupoProfesional.getLength());
          
        Node nNode_grupo_profesional = nodeListGrupoProfesional.item(empleado_grupo-1);
      
        Element element_NivelCat = (Element) nNode_grupo_profesional;

        NodeList nNode_grupo_profesional_hijos = element_NivelCat.getElementsByTagName("niveles_de_categorias");
        
//        System.out.println(nNode_grupo_profesional_hijos.getLength());
        
         Element element_Nivel = (Element) nNode_grupo_profesional_hijos.item(0);
         
         NodeList nodeNivel = element_Nivel.getElementsByTagName("nivel");
        System.out.println(nodeNivel.getLength());
        for (int i = 0; i < nodeNivel.getLength(); i++) {
            
            Node nodos_Niveles = nodeNivel.item(i);
            
          Element elementoNivel = (Element) nodos_Niveles;
            
          String nivel = elementoNivel.getAttribute("numero");
            System.out.println("nivel");
            if(nodeNivel.getLength() == 1 || Integer.parseInt(nivel) == empleado_nivel){
                NodeList nodelist_nombrecategoria = elementoNivel.getElementsByTagName("nombre_categoria");
                for (int j = 0; j < nodelist_nombrecategoria.getLength(); j++) {
                     Node nodos_nombrecat = nodelist_nombrecategoria.item(j);
            
                        Element elementosNombreCat = (Element) nodos_nombrecat;
                        String letra = elementosNombreCat.getAttribute("letra");
                         if(empleado_letra == null || letra.equals(empleado_letra)){ 
                             System.out.println(elementosNombreCat.getTextContent());
                         }
                }
            }// el ombre del los empleados no hace falta comprobar
            
            
            
            
            NodeList nNode_grupo_profesional_salarios = element_NivelCat.getElementsByTagName("salario");
        
         
            
            for (int j = 0; j < nNode_grupo_profesional_salarios.getLength();j++) {
                Element element_salarioActual = (Element) nNode_grupo_profesional_salarios.item(j);
                if(Integer.parseInt(element_salarioActual.getAttribute("nivel")) == empleado_nivel){
                    if (empleado_letra == null || empleado_letra.equals(element_salarioActual.getAttribute("letra"))) {
                        System.out.println(element_salarioActual.getTextContent());
                    }
                }
            }
            
            
            
            
            
//           Node nodeNumeroAtributo = nodos_Niveles.item(i).getAttributes().getNamedItem("numero");
           

        }

//        for (int o = 0; o < nodeListGrupoProfesional.getLength(); o++) {
//            Node nNode_grupo_profesional = nodeListGrupoProfesional.item(o);
//
//            if (nNode_grupo_profesional.getNodeType() == Node.ELEMENT_NODE) {
//                Element eElement = (Element) nNode_grupo_profesional;
//
//                System.out.println("El grupo profesionale es : " + eElement.getAttribute("numero"));
//
//                NodeList nodeListNiveles_de_categorias = doc.getElementsByTagName("niveles_de_categorias");
//                //Obtengo todos los nodos de <salarios> de toodo el fichero xml:
//
//                for (int i = 0; i < nodeListNiveles_de_categorias.getLength(); i++) {
//
//                    Node nNode_nodeListNiveles_de_categorias = nodeListNiveles_de_categorias.item(i);
//
//                    if (nNode_nodeListNiveles_de_categorias.getNodeType() == Node.ELEMENT_NODE) {
//                        Element eElements = (Element) nNode_nodeListNiveles_de_categorias;
//                        if (i == o) {
//
//                            NodeList elementsNivel = eElements.getElementsByTagName("nivel");
//                            //Obtengo la lista de los nodos de <salarios numero="i"> de toodo el fichero xml:
//
////                            System.out.println("Salario " + (i + 1) + ":");
//                            for (int j = 0; j < elementsNivel.getLength(); j++) {
//                                System.out.println("Nivel " + (j + 1) + " = " + eElements.getElementsByTagName("nivel").item(j).getTextContent());
//                                // <salario nivel="j">...</salario>
//
//                            }
//
//                            System.out.println("");
//                        }
//                    }
//                }
//
////                NodeList nodeniveles_de_categorias = doc.getElementsByTagName("niveles_de_categorias");
////                System.out.println(nodeniveles_de_categorias.getLength());
////                for (int i = 0; i < nodeniveles_de_categorias.getLength(); i++) {
////                    
////                    Node nNodeniveles_de_categorias = nodeniveles_de_categorias.item(i);
////                    System.out.println(i);
////                    if (nNodeniveles_de_categorias.getNodeType() == Node.ELEMENT_NODE) {
////                        
////                        Element eElement_nivel_niveles_de_categorias = (Element) nNodeniveles_de_categorias;
////
////                        NodeList nodeListNivel = doc.getElementsByTagName("nivel");
////                        
//////                        System.out.println(nodeListNivel.getLength());
////                        
////                        for (int niv = 0; niv < nodeListNivel.getLength(); niv++) {
////                            
////                            Node nNodeNivel2 = nodeListNivel.item(niv);
////
////                            if (nNodeNivel2.getNodeType() == Node.ELEMENT_NODE) {
////                                
////                                Element eElementnivel2 = (Element) nNodeNivel2;
////                                
////                                String numero =eElementnivel2.getAttribute("numeroN");
//////                                System.out.println("El nivel es : " + numero);
////                                
//////                                System.out.println("El nombre de la categoria es: " + eElementnivel2.getElementsByTagName("nombre_categoria").item(niv).getTextContent());
////
////                            }
////                        }
////
////                    }
//            }
//
//            // soutr de  anteriores
//            NodeList nodeListSalarios = doc.getElementsByTagName("salarios");
//            //Obtengo todos los nodos de <salarios> de toodo el fichero xml:
//
//            for (int i = 0; i < nodeListSalarios.getLength(); i++) {
//
//                Node nNodesal = nodeListSalarios.item(i);
//
//                if (nNodesal.getNodeType() == Node.ELEMENT_NODE) {
//                    Element eElements = (Element) nNodesal;
//                    if (i == o) {
//
//                        NodeList elementsSalario = eElements.getElementsByTagName("salario");
//                        //Obtengo la lista de los nodos de <salarios numero="i"> de toodo el fichero xml:
//
//                        System.out.println("Salario " + (i + 1) + ":");
//                        for (int j = 0; j < elementsSalario.getLength(); j++) {
//                            System.out.println("Nivel " + (j + 1) + " = " + eElements.getElementsByTagName("salario").item(j).getTextContent());
//                            // <salario nivel="j">...</salario>
//
//                        }
//                        System.out.println("______________");
//                        System.out.println("");
//                    }
//                }
//            }
//        }
    }
}
//}
