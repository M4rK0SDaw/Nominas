/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package leer_xml;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;

/**
 *
 * @author Karol
 */
public class Leer_xml {

    private static final String FILENAME = "C:\\Users\\marqu\\OneDrive\\Documentos\\NetBeansProjects\\Mis_clases_Java\\Leer_XML\\Leer_xml\\build\\classes\\leer_xml\\convenio.xml";

    public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException {

        // instancia la factoria
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

        // Parsear el fichero de XML
        DocumentBuilder db = dbf.newDocumentBuilder();
        Document doc = db.parse(new File(FILENAME));

        // http://stackoverflow.com/questions/13786607/normalization-in-dom-parsing-with-java-how-does-it-work
        // Quitar infromacion redundante
        doc.getDocumentElement().normalize();
//                                          doc  busca root      devuelve nombre de la raiz o root
        System.out.println("Nodo raiz :" + doc.getDocumentElement().getNodeName());
        System.out.println("------");

        NodeList nodeListGrupoProfesional = doc.getElementsByTagName("grupo_profesional");

        for (int o = 0; o < nodeListGrupoProfesional.getLength(); o++) {
            Node nNode = nodeListGrupoProfesional.item(o);

            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                Element eElement = (Element) nNode;
                System.out.println("El nombre de la categoria es: " + eElement.getElementsByTagName("nombre_categoria").item(0).getTextContent());
                System.out.println("El grupo profesionale es : " + eElement.getAttribute("numero"));
                System.out.println("........");

                // soutr de  anteriores
                NodeList nodeListSalarios = doc.getElementsByTagName("salarios");
                //Obtengo todos los nodos de <salarios> de toodo el fichero xml:
                // <salarios>
                //      <salario nivel=1>...</salario>
                //      <salario nivel=2>...</salario>
                //      ...
                // </salarios>
                // ...
                // <salarios>
                //      <salario nivel=1>...</salario>
                //      <salario nivel=2>...</salario>
                //      ...
                // </salarios>

                for (int i = 0; i < nodeListSalarios.getLength(); i++) {

                    Node nNodesal = nodeListSalarios.item(i);

                    if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                        Element eElements = (Element) nNodesal;
                        if (i == o) {

                            NodeList elementsSalario = eElements.getElementsByTagName("salario");
                            //Obtengo la lista de los nodos de <salarios numero="i"> de toodo el fichero xml:
                            // <salarios numero="i">
                            //      <salario nivel=1>...</salario>
                            //      <salario nivel=2>...</salario>
                            //      ...
                            // </salarios>

                            System.out.println("Salario " + (i + 1) + ":");
                            for (int j = 0; j < elementsSalario.getLength(); j++) {
                                System.out.println("Nivel " + (j + 1) + " = " + eElements.getElementsByTagName("salario").item(j).getTextContent());
                                // <salario nivel="j">...</salario>
                            }
                            System.out.println();
                        }
                    }
                }
            }
        }
    }
}
