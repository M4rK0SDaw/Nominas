/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package generador_de_nominas.Menus;

/**
 *
 * @author Marek
 */
public class Menus {

    public static void cls(int num) {
        for (int i = 0; i < num; i++) {
            System.out.println();
        }
    }

    public static void pausa() {
        System.out.println(" Pulse la tecla enter pa seguir....");
        //  SLeer2.limpiar();
        cls(3);
    }

    public void menu() {
        cls(15);
        System.out.println(
                "     *                 MENÚ             *\n"
                + "     ************************************\n"
                + "     *                                  *\n"
                + "     *        [1] GENERATE PAYROLL      *\n"
                + "     *                                  *\n"
                + "     *        [2]  ADD                  *\n"
                + "     *                                  *\n"
                + "     *        [3] SEARCH                *\n"
                + "     *                                  *\n"
                + "     *        [4] MODIFY                *\n"
                + "     *                                  *\n"
                + "     *        [5] VISUALIZE             *\n"
                + "     *                                  *\n"
                + "     *        [6] EXIT                  *\n"
                + "     *                                  *\n"
                + "     ************************************\n");
        cls(1);
        System.out.println("¿Como desea inciciar?");
        int numero = 0;

        switch (numero) {
            case 1:
                menu_Payroll();
                break;
            case 2:
                menu_Add();
                break;
            case 3:
                menu_Search();
                break;
            case 4:
                menu_Modify();
                break;
            case 5:

                break;
            case 6:

                break;
            default:
                System.err.println("Opcion erronea, vuelva a seleccionar");
                break;

        }
    }

    public void menu_Payroll() {

        cls(15);
        System.out.println(
                "     *           Payroll Generator             *\n"
                + "     ************************************\n"
                + "     *                                   *\n"
                + "     *        [1] FOR BUISNESS           *\n"
                + "     *                                   *\n"
                + "     *        [2] FOR EMPLOYEE           *\n"
                + "     *                                   *\n"
                + "     *        [3] EXIT                   *\n"
                + "     ************************************\n");
        cls(1);
        System.out.println("¿Como desea inciciar?");
        // leer la eleccion del menu
        int numero = 0;

        switch (numero) {
            case 1:

                break;
            case 2:

                break;

            case 3:
                break;
            default:
                System.err.println("Opcion erronea, vuelva a seleccionar");
                break;
        }
    }

    public void menu_Add() {

        cls(15);
        System.out.println(
                "     *                  ADD               *\n"
                + "     ************************************\n"
                + "     *                                   *\n"
                + "     *        [1] ADD BUISNESS           *\n"
                + "     *                                   *\n"
                + "     *        [2] ADD EMPLOYEE           *\n"
                + "     *                                   *\n"
                + "     *        [3] EXIT FROM ADD          *\n"
                + "     ************************************\n");
        cls(1);
        System.out.println("¿Como desea inciciar?");
        // leer la eleccion del menu
        int numero = 0;

        switch (numero) {
            case 1:

                break;
            case 2:

                break;

            case 3:
                break;
            default:
                System.err.println("Opcion erronea, vuelva a seleccionar");
                break;
        }
    }

    public void menu_Search() {

        cls(15);
        System.out.println(
                "     *                  SEARCH               *\n"
                + "     ************************************\n"
                + "     *                                   *\n"
                + "     *        [1] SEARCH BUISNESS        *\n"
                + "     *                                   *\n"
                + "     *        [2] SEARCH EMPLOYEE        *\n"
                + "     *                                   *\n"
                + "     *        [3] EXIT FROM SEARCH       *\n"
                + "     ************************************\n");
        cls(1);
        System.out.println("¿Como desea inciciar?");
        // leer la eleccion del menu
        int numero = 0;

        switch (numero) {
            case 1:

                break;
            case 2:

                break;

            case 3:
                break;
            default:
                System.err.println("Opcion erronea, vuelva a seleccionar");
                break;
        }
    }

    public void menu_Modify() {

        cls(15);
        System.out.println(
                "     *                  MODIFY               *\n"
                + "     ************************************\n"
                + "     *                                   *\n"
                + "     *        [1] MODIFY BUISNESS        *\n"
                + "     *                                   *\n"
                + "     *        [2] MODIFY EMPLOYEE        *\n"
                + "     *                                   *\n"
                + "     *        [3] EXIT FROM MODIFY       *\n"
                + "     ************************************\n");
        cls(1);
        System.out.println("¿Como desea inciciar?");
        // leer la eleccion del menu
        int numero = 0;

        switch (numero) {
            case 1:

                break;
            case 2:

                break;

            case 3:
                break;
            default:
                System.err.println("Opcion erronea, vuelva a seleccionar");
                break;
        }
    }
    

    
     public void menu_Modify() {

        cls(15);
        System.out.println(
                "     *                  MODIFY               *\n"
                + "     ************************************\n"
                + "     *                                   *\n"
                + "     *        [1] MODIFY BUISNESS        *\n"
                + "     *                                   *\n"
                + "     *        [2] MODIFY EMPLOYEE        *\n"
                + "     *                                   *\n"
                + "     *        [3] EXIT FROM MODIFY       *\n"
                + "     ************************************\n");
        cls(1);
        System.out.println("¿Como desea inciciar?");
        // leer la eleccion del menu
        int numero = 0;

        switch (numero) {
            case 1:

                break;
            case 2:

                break;

            case 3:
                break;
            default:
                System.err.println("Opcion erronea, vuelva a seleccionar");
                break;
        }
    }
    

}
